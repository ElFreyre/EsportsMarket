<?php
defined("BASEPATH") or exit("ACCESO RESTRINGIDO");

class OGlog_controller extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model("OG_model");
		if(!$this->session->login){
			redirect("OG_controller");
		}
	}

	function index(){
		# Archivo de Configuracion
		$datah["titulopagina"]="Pagina de Inicio de la organización";
		$this->load->view("includes/header",$datah);
		$this->load->view("OG/menuOGlog");
		$this->load->view("OG/perfilActualizaOG");
		$this->load->view("includes/footer");
	}
	function actualiza(){
		if($this->input->post()and $this->input->post('btn_update')){
			$id=$_SESSION['id'];	
			$nombre= $this->input->post("nomOG");
			$fecha= $this->input->post("fecCreOG");
			$descripcion= $this->input->post("desOG");
			$imagen=$this->input->post("imagen");
			//Recepción de imagen
        	//$nombreimagen    =  $_FILES["imagen"]['name'];   //obtiene el nombre    
        	//$archivo   =  $_FILES["imagen"]['tmp_name'];  //contiene el archivo
        	//$ruta      =   "assets/imgPerfil";
        	//$ruta      =   $ruta."/".$nombreimagen; 
       		// move_uploaded_file($archivo,$ruta);
      		//--Termina imagen  

			# Ejecutams la Validacion de la captura
				$data["Nombre"]          = $nombre;
				$data["Fundacion"]       = $fecha;
				$data["Description"] 	 = $descripcion;
				$data["Tag"]             = $tag;
				$data["imgLogo"]         = $imagen;

				$this->OG_model->update($data,$id);
				$error = $this->db->error();
				if($error['code'] ==0){
					redirect(base_url()."index.php/jugadorlog_controller");
				} else {
					$errores = "Existe inconsistencia en la BD con sus datos, verifique";
				}
			}
		}

		function solicitud(){
			if($this->input->post() and $this->input->post('btn_solicitud')){
			#Guardamos parte del login en una variable
			$id=$_SESSION['id'];
			#Vamos a registrar al alumno
			$Titulo = $this->input->post('TituloSol');
			$Descripcion = $this->input->post('Descripcion');
			$Pago = $this->input->post('Pago');
			$TiempoPago = $this->input->post('TiempoDePago');
			$juego =$this->input->post('juego');
			#Validacion de los datos
			$this->form_validation->set_error_delimiters('','.');
			if($this->form_validation->run('Solicitud') === TRUE){
				#Grabar los datos	
			$data['TituloSol']         = $Titulo;
			$data['Descripcion']       = $Descripcion;
			$data['Pago']              = $Pago;
			$data['TiempoDePago']      = $TiempoPago;
			$data['Estatus']		   = 1;
			$data['Equipo_idEquipo']   = $id;
			$data['Juegos_idJuegos']   = $juego;
			$this->OG_model->insertarSolicitud($data);
			}else{
				echo "Hubo un error en los datos";
				echo validation_errors();
			}
		}	
		$datah["titulopagina"] ="Solicitud ";
		$this->load->view('includes/header',$datah);
		$this->load->view('OG/menuOGlog');
		$this->load->view('OG/SolicitudOG');
		$this->load->view('includes/footer'); 
	}
}
