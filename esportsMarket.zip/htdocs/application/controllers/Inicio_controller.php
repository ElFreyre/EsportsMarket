<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inicio_controller extends CI_Controller {
	function __construct(){
		parent::__construct();
	}
	function index(){
		$datav["titulopagina"] ="Comenzando con CI3";
		$datab["username"]="Freyre Gonzalez";
		$this->load->view('includes/header',$datav);
		//$this->load->view('inicio/menu');
		$this->load->view('inicio/banner');
		$this->load->view('inicio/menu');
		//$this->load->view('inicio/contenido',$datab);
		$this->load->view('inicio/footer');
		$this->load->view('includes/footer');
	}

}