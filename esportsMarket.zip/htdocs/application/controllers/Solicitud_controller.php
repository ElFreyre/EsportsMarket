<?php
defined("BASEPATH") or exit("ACCESO RESTRINGIDO");

class Solicitud_controller extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model("jugador_model");
		$this->load->model("solicitud_model");
		$this->load->model("OG_model");
		$this->load->model("relacion_model");
		if(!$this->session->login){
			redirect("jugador_controller");
		}
	}
	function index(){
		$datah["titulopagina"] = "Ofertas de equipos";
		$this->load->view("includes/header", $datah);
		$this->load->view("jugador/menuJugadorLog");
		$data["tabla"] = $this->TablaSolicitud();
		$this->load->view("Solicitud/verSolicitud",$data);
		$this->load->view("includes/footer");
	}

	function TablaSolicitud(){
		$solicitudes = $this->solicitud_model->getAll();
		if($solicitudes->num_rows() > 0) {
			$tabla  = "<table id='mitabla' class='table table-bordered table-striped'><thead class='thead-dark'>";
			$tabla .= "<tr>
						<th>Equipo</th>
						<th>Titulo</th>
						<th>Descripcion</th>
						<th>Pago</th>
						<th>Tipo de pago</th>
						</tr>";
			$tabla .= "</thrad>";
			$tabla .= "<tbody>";
			foreach ($solicitudes->result() as $row)
			{
				#Empieza la tabla
				$idSolicitud= $row->idSolicitud;	
				$Titulo = $row->TituloSol;
				$Descripcion     = $row->Descripcion;
				$Pago    = $row->Pago;
				$Equipo =$row->Equipo_idEquipo;
				if($row->TiempoDePago = 1){
					$TiempoDePago="Quincenal";
				}else{
					$TiempoDePago="Mensual";
				}
				//$mod = base_url()."Persona_controller/editar/".$id_persona;
				//$bor = base_url()."Persona_controller/borrar/".$id_persona;
				//$rec = base_url()."Persona_controller/recuperar/".$id_persona;
				$tabla .= "<tr>";
				$tabla .= "<td>$Equipo</td>";
				$tabla .= "<td>$Titulo</td>";
				$tabla .= "<td>$Descripcion</td>";
				$tabla .= "<td>$Pago</td>";
				$tabla .= "<td>$TiempoDePago</td>";

				$tabla.='<td>
					<a href="'.base_url().'Solicitud_controller/insertarJugador/'.$idSolicitud.'" role="button">
					<i class="far fa-edit btn btn-light" title="Meter Solicitud">
					</i></a>
					</td>';
		/*		$tabla.='<td> 

					<a href="'.base_url().'Persona_controller/editar/'.$id_persona.'" role="button">
					<i class="far fa-edit btn btn-light" title="Editar Registro">
					</i></a>
					<a href="'.base_url().'Persona_controller/cerrar/'.$id_persona.'" role="button">
					<i class="fas fa-trash btn btn-light" title="Bloquear Registro">
					</i></a>
					<a href="'.base_url().'Persona_controller/abrir/'.$id_persona.'" role="button">
					<i class="fas fa-redo-alt btn btn-light" title="Desbloquear  Registro">
					</i></a>

				</td>';
				*/

				$tabla.='</tr>';
			
		}
			$tabla .= "</tbody></table>";

		} else {
			$tabla = "<h4 class='alert alert-danger text-center'>NO HAY solicitudes A MOSTRAR ...</h4>";
		}
	
		return $tabla;
	}
}
