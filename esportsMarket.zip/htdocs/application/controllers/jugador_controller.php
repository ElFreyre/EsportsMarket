<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class jugador_controller extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model("jugador_model");
	}
	function index(){

		if($this->input->post()){
			var_dump("Formulario fue enviado");
		}
		$datah["titulopagina"] ="Comenzando con CI3";
		$datab["username"]="Freyre Gonzalez";
		$this->load->view('includes/header',$datah);
		$this->load->view('jugador/menuJugador');
		$this->load->view('jugador/loginJugador');
		$this->load->view('includes/footer');
	}

	function registro(){
		if($this->input->post() and $this->input->post('btn_registro')){
			#Vamos a registrar al alumno
			$correo = $this->input->post('correoJug');
			$tag = $this->input->post('tagJug');
			$nombre = $this->input->post('nombreJug');
			$apellidosP = $this->input->post('apellidosPatJug');
			$apellidosM = $this->input->post('apellidosMatJug');
			$password = $this->input->post('password');

			#Validacion de los datos
			$this->form_validation->set_error_delimiters('','.');
			if($this->form_validation->run('jugador') === TRUE){
				#Grabar los datos

			
			$data['Nombre']          = $nombre;
			$data['ApPatJug']        = $apellidosP;
			$data['ApMatJug']        = $apellidosM;
			$data['CorreoJug']       = $correo;
			$data['PassJug']         = $password;
			$data['FechaNacJug']       =date("Y-m-d");
			$data['SexoJug']         = "Indefinido";
			$data['Tag']             = $tag;
			$data['Resultados']      ="not yet";
			$data['FotoPerfilJug']   ="not yet";
			$data['Juegos_idJuegos'] =1;

			$this->jugador_model->insertar($data);
			}else{
				echo "Hubo un error en los datos";
				echo validation_errors();
			}
			
		}
		$datah["titulopagina"] ="Comenzando con CI3";
		$datab["username"]="Freyre Gonzalez";
		$this->load->view('includes/header',$datah);
		$this->load->view('jugador/menuJugador');
		$this->load->view('jugador/registroJugador');
		$this->load->view('includes/footer');
	}
	function login(){

		if($this->input->post() and $this->input->post('btn-login')){

			$userid = $this->input->post('correojug',TRUE);
			$password = $this->input->post('password',TRUE);

			#Limpiamos los datos capturados.
			$userid = $this->security->xss_clean(strip_tags($userid));
			$password = $this->security->xss_clean(strip_tags($password));

			$row = $this->jugador_model->login($userid, $password);
			if($row != NULL){
				# Creamos la sesion del Jugador
				$this->session->set_userdata('correo',$row->CorreoJug);
				$this->session->set_userdata('juego',$row->Juegos_idJuegos);
				$this->session->set_userdata('id',$row->idJugador);
				$this->session->set_userdata('login',TRUE);
				redirect("jugadorlog_controller");
			} else {

				echo "No Ok";
			}
		}
		$datah["titulopagina"] ="Comenzando con CI3";
		$datab["username"]="Freyre Gonzalez";
		$this->load->view('includes/header',$datah);
		$this->load->view('jugador/menuJugador');
		$this->load->view('jugador/loginJugador');
		$this->load->view('includes/footer'); 
	}
		function logout(){
		unset(
			$_SESSION['correo'],
			$_SESSION['juego'],
			$_SESSION['id'],
			$_SESSION['login']
		);
		$this->session->sess_destroy();
		redirect("jugador_controller");
	}
}