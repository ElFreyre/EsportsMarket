<?php
defined("BASEPATH") or exit("ACCESO RESTRINGIDO");

class jugadorlog_controller extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model("jugador_model");
		if(!$this->session->login){
			redirect("jugador_controller");
		}
	}

	function index(){
		# Archivo de Configuracion
		$datah["titulopagina"]="Pagina de Inicio del Jugador";
		$this->load->view("includes/header",$datah);
		$this->load->view("jugador/menuJugadorLog");
		$this->load->view("jugador/updateJugador");
		$this->load->view("includes/footer");

	}
	function actualiza(){
		if($this->input->post()and $this->input->post('btn_update')){
			$id=$_SESSION['id'];	
			$tag= $this->input->post("tagJug");
			$juego= $this->input->post("juego");
			$resultados= $this->input->post("resultados");
			$sexo=$this->input->post("sexo");
			$password=$this->input->post("password");
			$imagen=$this->input->post("imagen");
			$fecNacJug=$this->input->post("fecNacJug");
			//Recepción de imagen
        	//$nombreimagen    =  $_FILES["imagen"]['name'];   //obtiene el nombre    
        	//$archivo   =  $_FILES["imagen"]['tmp_name'];  //contiene el archivo
        	//$ruta      =   "assets/imgPerfil";
        	//$ruta      =   $ruta."/".$nombreimagen; 
       		// move_uploaded_file($archivo,$ruta);
      		//--Termina imagen  

			# Ejecutams la Validacion de la captura
				$data["PassJug"]         = $password;
				$data["FechaNacjug"]     = $fecNacJug;
				$data["Sexojug"] 	     = $sexo;
				$data["Tag"]             = $tag;
				$data["Resultados"]      = $resultados;
				$data["FotoPerfilJug"]   = $imagen;
				$data["Juegos_idJuegos"] = $juego;

				$this->jugador_model->update($data,$id);
				$error = $this->db->error();
				if($error['code'] ==0){
					redirect(base_url()."index.php/jugadorlog_controller");
				} else {
					$errores = "Existe inconsistencia en la BD con sus datos, verifique";
				}

		}
		$datah["titulopagina"] ="Perfil";
		$this->load->view('includes/header',$datah);
		$this->load->view('jugador/menuJugadorLog');
		$this->load->view('jugador/updateJugador');
		$this->load->view('includes/footer');
	}

		function editar($idJugador = 0){

		$datah["titulopagina"] = "Perfil jugador";
		$datah["proceso"] = "Perfil del jugador";
		$datah["boton"]   = "Grabar Datos Modificados";
		$datah["readonly"] = 'readonly';

		if($this->input->post()){
			$row = $this->jugador_model->getId($idJugador);
			$this->cargaCampos($data,$row);
		}
		$datah["titulopagina"]="Perfil";
		$this->load->view("includes/header", $datah);
		$this->load->view("jugador/menuJugadorLog");
		$this->load->view("jugador/perfilJugador",$data);
		$this->load->view("includes/footer");

	}

	# Pasamos por referencia campos de la vista
	function cargaCampos(&$data,$row){

			# Inicializamos variables del formulario
			$data["idJugador"]     = $row->idJugador;
			$data["Nombre"]        = $row->Nombre;
			$data["apPatJug"]      = $row->apPatJug;
			$data["apMatJug"]      = $row->apMatJug;
			$data["CorreoJug"]     = $row->CorreoJug;
			$data["FechaNacjug"]   = $row->FechaNacjug;
			$data["Sexojug"]       = $row->Sexojug;
			$data["Tag"]           = $row->Tag;
			$data["Resultados"]	   = $row->Resultados;		

	}
	function TablaSolicitud(){
		$solicitudes = $this->jugador_model->getAll();
		if($solicitudes->num_rows() > 0) {
			$tabla  = "<table id='mitabla' class='table table-bordered table-striped'><thead class='thead-dark'>";
			$tabla .= "<tr>
						<th>Titulo/th>
						<th>Descripcion</th>
						<th>Pago</th>
						<th>Tipo de pago</th>
						</tr>";
			$tabla .= "</thrad>";
			$tabla .= "<tbody>";
			foreach ($solicitudes->result() as $row)
			{
				$Titulo = $row->TituloSol;
				$Descripcion     = $row->Descripcion;
				$Pago    = $row->Pago;
				if($row->TiempoDePago = 1){
					$TiempoDePago="Quincenal";
				}else{
					$TiempoDePago="Mensual";
				}
				//$mod = base_url()."Persona_controller/editar/".$id_persona;
				//$bor = base_url()."Persona_controller/borrar/".$id_persona;
				//$rec = base_url()."Persona_controller/recuperar/".$id_persona;
				$tabla .= "<tr>";
				$tabla .= "<td>$Titulo</td>";
				$tabla .= "<td>$Descripcion</td>";
				$tabla .= "<td>$Pago</td>";
				$tabla .= "<td>$TiempoDePago</td>";

		/*		$tabla.='<td> 

					<a href="'.base_url().'Persona_controller/editar/'.$id_persona.'" role="button">
					<i class="far fa-edit btn btn-light" title="Editar Registro">
					</i></a>
					<a href="'.base_url().'Persona_controller/cerrar/'.$id_persona.'" role="button">
					<i class="fas fa-trash btn btn-light" title="Bloquear Registro">
					</i></a>
					<a href="'.base_url().'Persona_controller/abrir/'.$id_persona.'" role="button">
					<i class="fas fa-redo-alt btn btn-light" title="Desbloquear  Registro">
					</i></a>

				</td>';
				*/

				$tabla.='</tr>';
			}
			$tabla .= "</tbody></table>";

		} else {
			$tabla = "<h4 class='alert alert-danger text-center'>NO HAY solicitudes A MOSTRAR ...</h4>";
		}
		return $tabla;
	}

}