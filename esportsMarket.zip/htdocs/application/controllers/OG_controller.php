<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class OG_controller extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model("OG_model");
	}
	function index(){

			if($this->input->post()){
			var_dump("Formulario fue enviado");
		}
		$datah["titulopagina"] ="Inicio Organización";
		$this->load->view('includes/header',$datah);
		$this->load->view('OG/menuOG');
		$this->load->view('OG/loginOG');
		$this->load->view('includes/footer');
		$this->load->view('OG/adOG');
		$this->load->view('inicio/footer');
	}
	function registro(){
		if($this->input->post() and $this->input->post('btn_registro')){
			#Vamos a registrar al alumno
			$correo = $this->input->post('correoOrg');
			$password = $this->input->post('password');

			#Validacion de los datos
			$this->form_validation->set_error_delimiters('','.');
			if($this->form_validation->run('OG') === TRUE){
				#Grabar los datos

			
			$data['Nombre']         = "not yet";
			$data['Fundacion']      = date("Y-m-d");
			$data['Registro']       = date("Y-m-d");
			$data['Adress']         = "not yet";
			$data['ImgLogo']        ="not yet";
			$data['Description']    = "Indefinido";
			$data['Location']       = "Not yet";
			$data['correoOrg']      =$correo;
			$data['PassOrg']   		=$password;

			$this->OG_model->insertar($data);
			}else{
				echo "Hubo un error en los datos";
				echo validation_errors();
			}
			
		}
		$datah["titulopagina"] ="Registro Organización";
		$datab["username"]="Freyre Gonzalez";
		$this->load->view('includes/header',$datah);
		$this->load->view('OG/menuOG');
		$this->load->view('OG/registroOG');
		$this->load->view('includes/footer');
		$this->load->view('OG/adOG');
		$this->load->view('inicio/footer');
	}
		function login(){

		if($this->input->post() and $this->input->post('btn-login')){

			$userid = $this->input->post('correoOrg',TRUE);
			$password = $this->input->post('password',TRUE);

			#Limpiamos los datos capturados.
			$userid = $this->security->xss_clean(strip_tags($userid));
			$password = $this->security->xss_clean(strip_tags($password));

			$row = $this->OG_model->login($userid, $password);
			if($row != NULL){
				# Creamos la sesion del Jugador
				$this->session->set_userdata('correo',$row->CorreoOG);
				$this->session->set_userdata('id',$row->idEquipo);
				redirect("OGlog_controller");
			} else {

				echo "No Ok";
			}
		}
		$datah["titulopagina"] ="Inicio de sesion";
		$datab["username"]="Freyre Gonzalez";
		$this->load->view('includes/header',$datah);
		$this->load->view('OG/menuOG');
		$this->load->view('OG/loginOG');
		$this->load->view('includes/footer'); 
		$this->load->view('inicio/footer');
	}
		function logout(){
		unset(
			$_SESSION['userid'],
			$_SESSION['username'],
			$_SESSION['login']
		);
		$this->session->sess_destroy();
		redirect("OG_controller");
	}

}