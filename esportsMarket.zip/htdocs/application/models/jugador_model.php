<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class jugador_model extends CI_Model{
	 function __construct(){
	 	parent::__construct();
	 }
	 function insertar($data){
	 	$this->db->insert("jugador",$data);
	 }
	 	function login($userid, $password){

		#Buscamos si forma parte del Comite administrador
		$this->db->where('correojug', $userid); 
		$this->db->where('passjug', $password); 
		$query = $this->db->get('jugador');//Consulta para buscar los datos 
		return $query->row();

	}
		function update($data,$userid){
		$this->db->where("idJugador",$userid);
		$this->db->update("jugador",$data);
	}
	function getId($idJugador){
		$this->db->where('idJugador',$idJugador);
		$resultSet = $this->db->get('jugador');
		return $resultSet->row();
	}

}