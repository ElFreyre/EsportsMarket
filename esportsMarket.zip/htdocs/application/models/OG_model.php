<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class OG_model extends CI_Model{
	 function __construct(){
	 	parent::__construct();
	 }

	 function insertar($data){
	 	$this->db->insert("equipo",$data);
	 }
	 function insertarSolicitud($data){
	 	$this->db->insert("solicitud",$data);
	 }
	 	function login($userid, $password){

		#Buscamos si forma parte de la tabla de organizador
		$this->db->where('correoOrg', $userid); 
		$this->db->where('passOrg', $password); 
		$query = $this->db->get('equipo');//Consulta para buscar los datos 
		return $query->row();

	}
		function update($data,$userid){
		$this->db->where("idEquipo",$userid);
		$this->db->update("equipo",$data);
	}
	function getAll(){
		return $this->db->get("equipo");
	}
}