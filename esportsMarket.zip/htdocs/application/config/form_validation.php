<?php

$config['error_prefix']='';
$config['error_suffix']='';

$config = array (
	'jugador' =>array(
		array(
		'field' => 'correoJug',//Nombre del campo en la base de dato
		'label' => 'Correo', //Nombre que retorna cuando marca error
		'rules' => 'trim|required|htmlspecialchars',
		),
		array(
		'field' => 'nombreJug',
		'label' => 'Nombre',
		'rules' => 'trim|required|htmlspecialchars',
		),
		array(
		'field' => 'tagJug',
		'label' => 'Tag',
		'rules' => 'trim|required|htmlspecialchars',
		),
		array(
		'field' => 'apellidosPatJug',
		'label' => 'Apellido paterno',
		'rules' => 'trim|required|htmlspecialchars',
		),
		array(
		'field' => 'apellidosMatJug',
		'label' => 'Apellido materno',
		'rules' => 'trim|required|htmlspecialchars',
		),
		array(
		'field' => 'password',
		'label' => 'Password',
		'rules' => 'trim|required|htmlspecialchars',
		)
	),
		'OG' =>array(
		array(
		'field' => 'correoOrg',
		'label' => 'Correo',
		'rules' => 'trim|required|htmlspecialchars',
		),
		array(
		'field' => 'password',
		'label' => 'Password',
		'rules' => 'trim|required|htmlspecialchars',
		)
	),
		'Solicitud'=>array(
		 array(
		'field' => 'TituloSol',
		'label' => 'Titulo',
		'rules' => 'trim|required|htmlspecialchars',
		),
		array(
		'field' => 'Descripcion',
		'label' => 'Descripcion',
		'rules' => 'trim|required|htmlspecialchars',
		 ),
		array(
		'field' => 'Pago',
		'label' => 'Pago',
		'rules' => 'trim|required|htmlspecialchars',
		 ),
		array(
		'field' => 'TiempoDePago',
		'label' => 'Tiempo de Pago',
		'rules' => 'trim|required|htmlspecialchars',
		 )
	)
);

/*$config= array(
	'OG' =>array(
		array(
		'field' => 'correoOg',
		'label' => 'Correo',
		'rules' => 'trim|required|htmlspecialchars',
		),
		array(
		'field' => 'password',
		'label' => 'Password',
		'rules' => 'trim|required|htmlspecialchars',
		)
	)
);*/
?>
