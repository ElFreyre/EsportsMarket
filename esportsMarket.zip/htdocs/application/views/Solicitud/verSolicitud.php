<div class="container">
	<div class="row">
		<div class="col">
			<div class="card">
				<div class="card-body">
					<a href="<?php echo base_url(); ?>Solicitud_controller/index" class="btn btn-info">Trabajos
					disponibles conforme al esport seleccionado</a>
					<?php echo $tabla; ?>
				</div>
			</div>					
		</div>
	</div>
</div>