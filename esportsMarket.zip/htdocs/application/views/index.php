<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<title>Iniciando con Code Igniter 3.1.10</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
		<h1>Comenzand con CI 3.1.10</h1>
		<p> Bienvenidos a un ambiente de desarrollo compacto y de poderoso como es CI3.</p>
		<hr>
</body>
</html>