<div class="container">
	<div class="row">
		<div class="col">
			<div class="card" style="width: 18rem;">
  <img src="<?php echo base_url();?>/assets/img/jugador2.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title text-center">Jugador</h5>
    <p class="card-text">Haz click en el boton para iniciar sesión como jugador y empezar a llenar tu futuro</p>
    <a href="<?php echo base_url(); ?>index.php/jugador_controller" class="btn btn-primary">Acceder</a>
  </div>
</div>
		</div>
				<div class="col">
			<div class="card" style="width: 18rem;">
        ​
 <img src="<?php echo base_url();?>/assets/img/coach.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Organizacion</h5>
    <p class="card-text">Haz click en el boton para iniciar sesión como organización y empezar a buscar talento.</p>
    <a href="<?php echo base_url(); ?>index.php/og_controller" class="btn btn-primary">acceder</a>
  </div>
</div>
		</div>
	</div>
</div>