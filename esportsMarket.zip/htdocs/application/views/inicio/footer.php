<div class="container">
	<div class="row">
		<div class="col text-center bg-dark text-light">
			<h6> Copyright 2019</h6>
		</div>
	</div>
</div>