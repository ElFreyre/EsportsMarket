
		<h1>Comenzando con CI 3.1.10</h1>
		<p> Bienvenidos a un ambiente de desarrollo compacto y de poderoso como es CI3.</p>

		<hr>
		<?php echo base_url();?>
		<hr>