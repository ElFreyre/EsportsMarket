<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<form method="post">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col">
         <div class="form-group">
    <label for="nocontrol">Correo</label>
    <input type="mail" class="form-control" id="correoJug" name="correoJug" placeholder="Coreo">
    <small id="emailHelp" class="form-text text-muted">Nunca compartiremos tu correo con nadie</small>
  </div>
    <div class="form-group">
    <label for="nocontrol">Tag</label>
    <input type="text" class="form-control" id="tagJug" name="tagJug" placeholder="Tag(Nickname)">
   
  </div>
  <div class="form-group">
    <label for="nocontrol">Nombre</label>
    <input type="text" class="form-control" id="nombreJug" name="nombreJug" placeholder="Nombre">
    
  </div>
   <div class="form-group">
    <label for="nocontrol">Apellido Paterno</label>
    <input type="text" class="form-control" id="apellidosPatJug" name="apellidosPatJug" placeholder="Apellido Paterno">
    
  </div>
     <div class="form-group">
    <label for="nocontrol">Apellido Materno</label>
    <input type="text" class="form-control" id="apellidosMatJug" name="apellidosMatJug" placeholder="Apellido Materno">
    
  </div>
  <div class="form-group">
    <label for="password">Contraseña</label>
    <input type="password" id="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
    <small id="emailHelp" class="form-text text-muted">Nunca te pediremos la contraseña por correo</small>
  </div>
  <input type="submit" name="btn_registro" class="btn btn-primary"></input>
</form>
        </div>
    </div>
</div>
</body>
</html>