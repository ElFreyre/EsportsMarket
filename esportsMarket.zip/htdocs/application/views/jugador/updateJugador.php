<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<form method="post">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col">
        <!--Imagen propiedad-->
          <div class="form-group">

    <input type="text" disabled="disabled"class="form-control"  placeholder="Foto de perfil">
  </div>
          <div class="container-login100-form-btn m-t-17">
          <input type="file" name="imagen" id="imagen" accept=".jpg">
          </div>

          <div class="container-login100-form-btn m-t-17">
    <div class="form-group">
    <label for="nocontrol">Tag</label>
    <input type="text" class="form-control" id="tagJug" name="tagJug" placeholder="Tag(Nickname)">
   </div>
       <div class="form-group">
    <input type="text" disabled="disabled"class="form-control" placeholder="Fecha de nacimiento">
   </div>
       <div class="form-group">
    <input type="date" class="form-control" id="fecNacJug" name="fecNacJug">
   </div>
   <!--Juegos -->
           <select name="juego" class="form-control">
            <option selected disabled>Juego al que te dedicas</option>
              <option value="1">League of Legends</option>
              <option value="2">Super Smash Bros. Ultimate</option>
              <option value="3">Super Smash Bros. Melee</option>
        </select>
  <div class="form-group">
    <label for="nocontrol">Resultados</label>
   <textarea name="resultados" class="form-control" id="resultados" rows="10" cols="40">Escribe aquí tus resultados</textarea>
    
  </div>
           <select name="sexo" class="form-control">
            <option selected disabled>Sexo</option>
              <option value="1">Masculino</option>
              <option value="2">Femenino</option>
        </select>

  <div class="form-group">
    <label for="password">Contraseña</label>
    <input type="password" id="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
    <small id="emailHelp" class="form-text text-muted">Nunca te pediremos la contraseña por correo</small>
  </div>
  <input type="submit" name="btn_update" class="btn btn-primary"></input>
</form>
        </div>
    </div>
</div>
</body>
</html>