<div class="container">
	<div class="row justify-content-center">
		<div class="col col-md-8">
			<div class="card">
				<div class="card-header">
					<h4 class="text-center"><?php echo $proceso; ?></h4>
				</div>
				<div class="card-body">
					<form action="" method="post" autocomplete="on">
						<?php
						echo idJugador("idJugador","Id del jugador", "required", $idJugador,$readonly);

						?>

					<!--	<div class="form-row">
							<div class="col">
								<div class="form-group">
								<?php
							//	echo nombre_persona("nombre","Nombre de la Persona","required",$nombre,"");
								?>
								</div>
							</div>
							<div class="col">
								<div class="form-group">
								<?php
							//	echo apellidos_persona("apellidos","Apellidos de la Persona","required",$apellidos,"");
								?>
								</div>
							</div>
						</div>
						<div class="form-row">
							<div class="col">
								<div class="form-group">
								<?php
							//	echo telefono("telefono","Telefono Movil o Fijo","required",$telefono,"");
								?>
								</div>
							</div>
							<div class="col">
								<div class="form-group">
								<?php
							//	echo email("email","Correo Electronico (email)","required",$email,"");
								?>
								</div>
							</div>
						</div>

						<div class="form-group">
							<?php
						//	echo password("password","Contraseña secreta","required",$apellidos,"");
							?>
						</div>
						<div class="form-row">
							<div class="col">
								<a href="<?php // echo base_url() ?>Persona_controller" class="btn btn-dark">Regresar Catálogo</a>
							</div>
							<div class="col">							
							</div>
						</div>
					-->
					</form>
				</div>
				<div class="card-footer">
					<?php
						if(isset($errores)) echo "Errores =>".$errores;
					?>
				</div>
			</div>
		</div>
	</div>
</div>