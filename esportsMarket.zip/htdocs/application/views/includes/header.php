<!DOCTYPE html>
<html>
<head>
	<title><?php echo $titulopagina;?></title>
	<link rel="stylesheet" type="text/css"
	href="<?php echo base_url();?>assets/bt4/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css"
	href="<?php echo base_url();?>assets/dt/css/datatables.min.css">
		<link rel="stylesheet" type="text/css"
	href="<?php echo base_url();?>assets/awesome/css/fontawesome.min.css">
		<link rel="stylesheet" type="text/css"
	href="<?php echo base_url();?>assets/css/dcc.css">
	 <link href="<?php echo base_url();?>assets/icons/css/simple-line-icons.css"
	  rel="stylesheet" type="text/css">
	<link href="<?php echo base_url();?>assets/fonts/css/all.min.css" rel="stylesheet">
</head>
<body>