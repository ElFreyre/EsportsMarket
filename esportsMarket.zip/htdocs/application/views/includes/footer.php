<script type="text/javascript" src="<?php echo base_url();?>assets/jquery/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/bt4/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/dt/js/datatables.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/awesome/js/fontawesome.min.js"></script>
</body>
</html>