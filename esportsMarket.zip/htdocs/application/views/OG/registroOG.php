<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<form method="post">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col">
         <div class="form-group">
    <label for="nocontrol">Correo</label>
    <input type="mail" class="form-control" id="correoOrg" name="correoOrg" placeholder="Coreo">
    <small id="emailHelp" class="form-text text-muted">Nunca compartiremos tu correo con nadie</small>
  </div>
  <div class="form-group">
    <label for="password">Contraseña</label>
    <input type="password" id="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
    <small id="emailHelp" class="form-text text-muted">Nunca te pediremos la contraseña por correo</small>
  </div>
  <input type="submit" name="btn_registro" class="btn btn-primary"></input>
</form>
        </div>
    </div>
</div>
</body>
</html>