<div class="container">
    <div class="row">
      <div class="col">
<nav class="navbar navbar-expand-lg navbar-light bg-primary">
  <a class="navbar-brand" href="<?php echo base_url(); ?>">Esports Market</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url(); ?>index.php/og_controller/registro">Registro</a>
      </li>
        <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url(); ?>index.php/og_controller/login">Iniciar sesión</a>
      </li>
      <a class="nav-item nav-link disabled"  tabindex="-1" aria-disabled="true">Organizacion</a>
    </ul>
  </div>
</nav>
      </div>
    </div>
  </div>