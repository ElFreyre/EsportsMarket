 <header class="jumbotron">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col">
        <h1 class="Jumbotron">
         ad
        </h1>
      </div>
    </div>
</div>
</header>