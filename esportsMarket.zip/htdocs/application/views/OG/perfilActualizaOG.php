<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<form method="post">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col">
        <!--Imagen propiedad-->
          <div class="form-group">

    <input type="text" disabled="disabled"class="form-control"  placeholder="Foto de perfil">
  </div>
          <div class="container-login100-form-btn m-t-17">
          <input type="file" name="imagen" id="imagen" accept=".jpg">
          </div>

          <div class="container-login100-form-btn m-t-17">
    <div class="form-group">
    <label for="nocontrol">Nombre</label>
    <input type="text" class="form-control" id="nomOG" name="nomOG" placeholder="Nombre de la organización (Ej:Counter logic gaming)">
   </div>
       <div class="form-group">
    <input type="text" disabled="disabled"class="form-control" placeholder="Fecha de creación">
   </div>
       <div class="form-group">
    <input type="date" class="form-control" id="fecCreOG" name="fecCreOG">
   </div>
   <!--Juegos -->
  <div class="form-group">
    <label for="nocontrol">Descripción de la organización</label>
   <textarea name="desOG" class="form-control" id="resultados" rows="10" cols="40" placeholder="Escriba aquí los detalles de su empresa, logros, juegos en los que participa, origen, creciemiento, etc">
     
   </textarea>
    
  </div>

  <input type="submit" name="btn_update" class="btn btn-primary"></input>
</form>
        </div>
    </div>
</div>
</body>
</html>