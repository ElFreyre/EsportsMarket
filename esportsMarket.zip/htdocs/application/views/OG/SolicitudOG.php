<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<form method="post">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col">
         <div class="form-group">
    <label for="pago">Titulo de la solicitud</label>
    <input type="text" id="TituloSol" name="TituloSol" class="form-control"  placeholder="Ejemplo: Jugador profesional de Smash Bros Ultimate">
  </div>
            <select name="juego" class="form-control">
            <option selected disabled>Jugador del juego necesitado</option>
              <option value="1">League of Legends</option>
              <option value="2">Super Smash Bros. Ultimate</option>
              <option value="3">Super Smash Bros. Melee</option>
        </select>
         <div class="form-group">
    <label for="nocontrol">Descripción</label>
     <textarea name="Descripcion" class="form-control" id="Descripción" rows="10" cols="40" placeholder="Escribe aquí los detalles del jugador a necesitar"></textarea>
  </div>
  <div class="form-group">
    <label for="pago">Pago</label>
    <input type="text" id="Pago" name="Pago" class="form-control" placeholder="Ej: $4000 MX">
  </div>
       <select name="TiempoDePago" class="form-control">
            <option selected disabled>Tiempo del pago</option>
              <option value="1">Quincenal</option>
              <option value="2">Mensual</option>
  <input type="submit" name="btn_solicitud" class="btn btn-primary"></input>
</form>
        </div>
    </div>
</div>
</body>
</html>