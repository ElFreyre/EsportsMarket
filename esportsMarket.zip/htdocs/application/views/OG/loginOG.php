<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<form method="post">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col">
  <div class="form-group">
    <label for="nocontrol">Correo electronico</label>
    <input type="email" class="form-control" id="correoOrg" name="correoOrg" placeholder="Correo electronico">
    <small id="emailHelp" class="form-text text-muted">Nunca mostraremos tu correo a nadie mas </small>
  </div>
  <div class="form-group">
    <label for="password">Contraseña</label>
    <input type="password" class="form-control" id="password" name="password" placeholder="Contraseña">
  </div>
  <input type="submit" name="btn-login" class="btn btn-primary"></input>
</form>
        </div>
    </div>
</div>
</body>
</html>